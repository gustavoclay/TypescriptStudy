export interface NegociacaoParcial {

    vezes: number;
    montante: number;
}